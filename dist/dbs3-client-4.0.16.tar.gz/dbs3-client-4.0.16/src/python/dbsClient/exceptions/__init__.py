#!/usr/bin/env python

__version__ = "$Revision: 1.1 $"
__revision__ = "$Id: __init__.py,v 1.1 2009/11/04 22:35:00 afaq Exp $"
__all__ = []

