#!/usr/bin/env python

__version__ = "$Revision: 1.1 $"
__revision__ = "$Id: __init__.py,v 1.1 2009/11/12 17:36:15 afaq Exp $"
__all__ = []

